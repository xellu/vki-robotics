//#include <stdio.h>
//#include <math.h>
//
//int main() {
//	double PI = 3.141;
//
//	float circleRadius;
//	float squareSide;
//
//	printf("circleRadius=");
//	scanf_s("%f", &circleRadius);
//
//	printf("squareSide=");
//	scanf_s("%f", &squareSide);
//
//	float circleSurface = PI * pow(circleRadius, 2);
//	float squareSurface = pow(squareSide, 2);
//
//	if (sqrt(squareSurface) > sqrt(circleSurface / PI)) {
//		printf("square won't fit");
//	}
//	else {
//		printf("square will fit");
//	}
//
//	return 0;
//}