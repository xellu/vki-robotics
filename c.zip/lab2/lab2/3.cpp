//#include <stdio.h>
//
//int main() {
//	float x, y;
//
//	printf("x=");
//	scanf_s("%f", &x);
//
//	printf("y=");
//	scanf_s("%f", &y);
//
//	//printf("x=%.3f y=%.3f x^2=%.3f\n", x, y, x * x);
//
//	if ((x <= 0 && y <= 1 && x >= -1 && y >= 0) || (y >= 0 && y <= 1 && y >= x * x)) {
//		printf("true");
//		return 0;
//	}
//
//
//	printf("false");
//	return 0;
//}