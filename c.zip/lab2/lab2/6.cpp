//#include <stdio.h>
//
//int main() {
//	int a, b, c, d, e;
//
//	printf("d=");
//	scanf_s("%d", &d);
//
//	printf("e=");
//	scanf_s("%d", &e);
//
//	printf("a=");
//	scanf_s("%d", &a);
//
//	printf("b=");
//	scanf_s("%d", &b);
//
//	printf("c=");
//	scanf_s("%d", &c);
//
//	if ((a <= d && b <= e) || (a <= e && b <= d) || (a <= d && c <= e) || (a <= e && c <= d) || (b <= d && c <= e) || (b <= e && c <= d)) {
//		printf("true");
//		return 0;
//	}
//	
//	printf("false");
//	return 0;
//}