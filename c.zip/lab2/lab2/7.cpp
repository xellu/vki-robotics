//#include <stdio.h>
//
//int main() {
//	int year;
//
//	printf("year=");
//	scanf_s("%d", &year);
//
//	if ((year % 4 == 0 || year % 100 == 0) && !(year % 400 == 0)) {
//		printf("true");
//		return 0;
//	}
//	
//	printf("false"); 
//
//	return 0;
//}