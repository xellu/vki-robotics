//#include <stdio.h>
//
//int main() {
//	int a, b, c;
//
//	a = 5;
//	b = 3;
//
//	printf("a=%i, b=%i", a, b);
//
//	c = b;
//	b = a;
//	a = c;
//
//	printf("\na=%i, b=%i", a, b);
//
//	//------------------
//
//	int x, y;
//	x = 4;
//	y = 2;
//
//	printf("\n\nx=%i, y=%i", x, y);
//
//	x += y;
//	y = x - y;
//	x = x - y;
//
//	printf("\nx=%i, y=%i", x, y);
//
//	return 0;
//}