//#include <stdio.h>
//
//int main() {
//	int sec;
//
//	printf("seconds from midnight> ");
//	scanf_s("%d", &sec);
//
//	int hours, mins, secs;
//
//	secs = sec;
//	mins = sec / 60;
//	hours = mins / 60;
//
//	mins -= hours * 60;
//	secs -= hours * 60 * 60 + mins * 60;
//
//	printf("h=%i, m=%i, s=%i", hours, mins, secs);
//
//}