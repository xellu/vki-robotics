//#include <stdio.h>
//
//int main() {
//	int a, b;
//
//	a = 5;
//	b = 7;
//
//	printf("%i + %i = %i", a, b, a + b);
//
//
//	return 0;
//}