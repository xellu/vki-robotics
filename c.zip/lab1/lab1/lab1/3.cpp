//#include <stdio.h>
//
//int main() {
//	int a, b;
//
//	a = 3;
//	b = 2;
//
//	printf("(%i + %i)^2 = %i\n", a, b, (a + b) * (a + b));
//	printf("%i^2 + %i^2 = %i", a, b, a * a + b * b);
//	
//	return 0;
//}