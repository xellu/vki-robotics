//#include <stdio.h>
//#include <math.h>
//
//int main() {
//	int a, b, c;
//
//	printf("a=");
//	scanf_s("%d", &a);
//
//	printf("b=");
//	scanf_s("%d", &b);
//
//	c = sqrt(a * a + b * b);
//	printf("c=%i", c);
//
//	return 0;
//}