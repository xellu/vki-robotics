//#include <stdio.h>
//#include <math.h>
//
//int main() {
//	int x1, y1, x2, y2;
//
//	x1 = 5;
//	y1 = 0;
//
//	x2 = 0;
//	y2 = 5;
//
//	lenX = abs(x1 - x2);
//	lenY = abs(y1 - y2);
//
//	distance = sqrt(lenX * lenX + lenY * lenY);
//
//	printf("distance=%i", distance);
//}